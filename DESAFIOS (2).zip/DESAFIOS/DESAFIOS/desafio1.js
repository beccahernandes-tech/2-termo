const entrada = require(`readline-sync`);
const nome = entrada.question("Qual e seu nome?");
const nascimento = entrada.questionInt("Qual e sua data de nascimento?");

let idade= 2026 - nascimento;

if (idade > 16 ) {
    console.log(`Olá ${nome} tem idade sulficiente para votar!`);
} else {
    console.log(`Olá ${nome} você não tem idade para votar`)

}