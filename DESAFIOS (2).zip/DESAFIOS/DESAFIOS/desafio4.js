const entrada = require(`readline-sync`);
const idade = entrada.questionInt("Qual e a sua idade?");

if (idade >= 5 && idade <= 10) {
    console.log("Voce esta na classificação INFATIL")
} 
else if (idade >= 11 && idade <= 17) {
    console.log("Você esta na classificacao JUVENIL")
}
else if (idade >= 18 && idade <= 60) {
    console.log("Voce esta na classificacao de ADULTO")
} else {
    console.log("Voce esta na classificacao SENIOR")
}
