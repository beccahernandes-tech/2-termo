const entrada = require(`readline-sync`);
const alcool = entrada.questionFloat("Qual e o preCo do litro do alcool?");
const gasolina = entrada.questionFloat("Qual e o preco do litro da gasolina?");

preco = alcool/gasolina

if (preco < 0.7) {
    console.log("Abasteça com ALCOOL")
} else {
    console.log("Abasteça com GASOLINA")
}
