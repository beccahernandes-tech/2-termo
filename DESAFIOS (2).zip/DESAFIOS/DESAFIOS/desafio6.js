const entrada = require(`readline-sync`);
const idade = entrada.questionInt("Qual e a sua idade?")
const autorização = entrada.keyInYNStrict("Voce tem autorizacao para entrar na sala?")
const acompanhado = entrada.keyInYNStrict("Voce esta acompanhado?")
const suspenso = entrada.keyInYNStrict("O aluno esta suspenso?") 

if (suspenso == true) {
    console.log("ACESSO NEGADO ! ") 
}
else if (idade >= 16 && autorização === true || acompanhado === true) {
    console.log("Acesso Liberado ! ")
} else {
    console.log("ACESSO NEGADO !")
}


// toUpperCase : é para deixar as letras maiusculas
