const entrada = require(`readline-sync`);
const conta = entrada.questionInt("Qual e o valor da sua conta?");


if (conta > 100) {
    valor = conta * 0.9;
    console.log(`Sua conta com desconto de 10% deu ${valor}`)
} else { 
    console.log("Você não houve nenhum desconto");
}